#Kaltura Python API Unittest Framework
# Michael McFadden (flipmcf@gmail.com)